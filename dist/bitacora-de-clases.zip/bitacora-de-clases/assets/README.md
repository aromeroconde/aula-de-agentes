# Activos opcionales

Guarda aquí plantillas visuales, portadas o elementos de marca reutilizables. No incorpores grabaciones ni transcripciones privadas al paquete de la skill.

