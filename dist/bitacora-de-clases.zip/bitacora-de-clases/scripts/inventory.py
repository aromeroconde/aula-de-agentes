#!/usr/bin/env python3
"""Inventaría fuentes de una clase sin modificar la carpeta original."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


CATEGORIES = {
    "transcript": {".docx", ".txt", ".vtt", ".srt", ".pdf"},
    "recording": {".mp4", ".mov", ".m4a", ".mp3", ".wav"},
    "support": {".xlsx", ".xls", ".csv", ".pptx", ".key"},
    "visual": {".png", ".jpg", ".jpeg", ".svg", ".webp"},
}


def category(path: Path) -> str:
    suffix = path.suffix.lower()
    for name, extensions in CATEGORIES.items():
        if suffix in extensions:
            return name
    return "other"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    root = args.folder.expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"No es una carpeta: {root}")

    files = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        files.append(
            {
                "name": path.name,
                "relative_path": str(path.relative_to(root)),
                "category": category(path),
                "extension": path.suffix.lower(),
                "size_bytes": path.stat().st_size,
            }
        )
    print(json.dumps({"root": str(root), "files": files}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
