#!/usr/bin/env python3
"""Compone una nueva página de Aula de Agentes desde un class-spec verificado."""

from __future__ import annotations

import argparse
import html
import json
import re
import shutil
import subprocess
import tempfile
import unicodedata
import zipfile
from datetime import date
from pathlib import Path
from xml.etree import ElementTree


SKILL_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_ROOT / "assets" / "class-page.html.tmpl"
REQUIRED = {
    "id",
    "title",
    "titleLines",
    "date",
    "dateLabel",
    "duration",
    "durationSeconds",
    "teacher",
    "thesis",
    "summaryTeaser",
    "summaryTitle",
    "standfirst",
    "sections",
    "moments",
    "knowledge",
    "evidenceChecks",
    "videoEmbedUrl",
    "videoViewUrl",
    "sources",
}


def fail(message: str) -> None:
    raise SystemExit(message)


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def slug(value: str) -> str:
    table = str.maketrans("áéíóúüñÁÉÍÓÚÜÑ", "aeiouunAEIOUUN")
    clean = value.translate(table).lower()
    return re.sub(r"[^a-z0-9]+", "-", clean).strip("-") or "momento"


def resolve_source(value: str, spec_dir: Path) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (spec_dir / path).resolve()


def validate(spec: dict) -> None:
    missing = sorted(REQUIRED - spec.keys())
    if missing:
        fail(f"Faltan campos obligatorios: {', '.join(missing)}")
    if not re.fullmatch(r"[0-9]{3}", str(spec["id"])):
        fail("id debe tener exactamente tres dígitos, por ejemplo 002")
    if len(spec["moments"]) < 3 or len(spec["sections"]) < 3 or len(spec["knowledge"]) < 3:
        fail("Se requieren al menos tres momentos, tres secciones y tres respuestas verificadas")
    if len(spec["evidenceChecks"]) < 5:
        fail("Se requieren al menos cinco afirmaciones contrastadas con la transcripción")
    try:
        date.fromisoformat(spec["date"])
    except (TypeError, ValueError):
        fail("date debe usar el formato YYYY-MM-DD")
    if not isinstance(spec["titleLines"], list) or not spec["titleLines"]:
        fail("titleLines debe contener al menos una línea")
    for index, moment in enumerate(spec["moments"], 1):
        for key in ("time", "seconds", "title", "text"):
            if key not in moment:
                fail(f"Momento {index}: falta {key}")
    for index, item in enumerate(spec["knowledge"], 1):
        for key in ("terms", "answer", "evidence"):
            if key not in item:
                fail(f"Knowledge {index}: falta {key}")


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFD", value.lower())
    value = "".join(char for char in value if unicodedata.category(char) != "Mn")
    return " ".join(value.split())


def transcript_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        with zipfile.ZipFile(path) as archive:
            root = ElementTree.fromstring(archive.read("word/document.xml"))
        return " ".join(node.text or "" for node in root.iter() if node.tag.endswith("}t"))
    if suffix in {".txt", ".vtt", ".srt"}:
        return path.read_text(encoding="utf-8", errors="ignore")
    fail("La validación automática de evidencia admite transcripciones DOCX, TXT, VTT o SRT")


def validate_evidence(spec: dict, spec_dir: Path) -> None:
    transcript = resolve_source(spec["sources"]["transcript"], spec_dir)
    if not transcript.is_file():
        fail(f"No existe la transcripción: {transcript}")
    source = normalize_text(transcript_text(transcript))
    for index, check in enumerate(spec["evidenceChecks"], 1):
        for key in ("claim", "evidence", "sourceExcerpt"):
            if not check.get(key):
                fail(f"Evidence check {index}: falta {key}")
        excerpt = normalize_text(check["sourceExcerpt"])
        if len(excerpt.split()) < 5:
            fail(f"Evidence check {index}: sourceExcerpt es demasiado corto")
        if excerpt not in source:
            fail(f"Evidence check {index}: el fragmento no aparece en la transcripción")


def extract_or_copy_frames(spec: dict, spec_dir: Path, build_dir: Path) -> list[dict]:
    frames_dir = build_dir / "assets" / "frames"
    frames_dir.mkdir(parents=True)
    recording = resolve_source(spec["sources"]["recording"], spec_dir)
    ffmpeg = shutil.which("ffmpeg")
    moments = []
    for index, original in enumerate(spec["moments"], 1):
        moment = dict(original)
        filename = f"{index:02d}-{slug(moment['title'])}.jpg"
        destination = frames_dir / filename
        if moment.get("imageSource"):
            source = resolve_source(moment["imageSource"], spec_dir)
            if not source.is_file():
                fail(f"No existe el fotograma: {source}")
            shutil.copy2(source, destination)
        else:
            if not recording.is_file():
                fail(f"No existe la grabación para extraer fotogramas: {recording}")
            if not ffmpeg:
                fail("ffmpeg no está disponible y el momento no tiene imageSource")
            result = subprocess.run(
                [ffmpeg, "-hide_banner", "-loglevel", "error", "-ss", str(moment["seconds"]), "-i", str(recording), "-frames:v", "1", "-q:v", "3", "-y", str(destination)],
                capture_output=True,
                text=True,
            )
            if result.returncode or not destination.is_file():
                fail(f"No se pudo extraer {filename}: {result.stderr.strip()}")
        moment.pop("imageSource", None)
        moment["image"] = f"assets/frames/{filename}"
        moments.append(moment)
    return moments


def title_html(lines: list[str], accent_index: int) -> str:
    rendered = []
    for index, line in enumerate(lines):
        value = esc(line)
        rendered.append(f"<i>{value}</i>" if index == accent_index else value)
    return "<br />".join(rendered)


def render_sections(spec: dict) -> tuple[str, str]:
    nav = []
    sections = []
    for index, section in enumerate(spec["sections"], 1):
        section_id = section.get("id") or f"seccion-{index}"
        heading = section["title"]
        nav.append(f'<a href="#{esc(section_id)}">{esc(heading)}</a>')
        paragraphs = "".join(f"<p>{esc(text)}</p>" for text in section.get("paragraphs", []))
        quote = section.get("quote")
        quote_html = ""
        if quote:
            quote_html = f'<blockquote>“{esc(quote["text"])}”<cite>{esc(quote.get("evidence", ""))}</cite></blockquote>'
        rule = section.get("rule")
        rule_html = ""
        if rule:
            rule_html = f'<div class="operating-rule"><span>REGLA OPERATIVA</span><strong>{esc(rule)}</strong></div>'
        sections.append(f'<section id="{esc(section_id)}"><h3>{esc(heading)}</h3>{paragraphs}{quote_html}{rule_html}</section>')
    return "".join(nav), "".join(sections)


def render_commitments(spec: dict) -> str:
    commitments = spec.get("commitments", [])
    if not commitments:
        return ""
    items = []
    for item in commitments:
        status = item.get("status", "pending")
        label = {"confirmed": "Confirmado", "proposed": "Propuesto", "pending": "Pendiente"}.get(status, status)
        owner = f' · {esc(item["owner"])}' if item.get("owner") else ""
        due = f' · {esc(item["dueDate"])}' if item.get("dueDate") else ""
        items.append(f"<li><span>{esc(label)}</span>{esc(item['text'])}{owner}{due}</li>")
    return f'<section class="commitments"><h3>Lo que quedó para continuar</h3><ul>{"".join(items)}</ul><p class="source-note">Los compromisos confirmados se separan de las propuestas. No se inventaron responsables ni fechas.</p></section>'


def chrome_binary() -> str | None:
    candidates = [
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ]
    return next((str(item) for item in candidates if item and Path(item).exists()), None)


def make_pdf(page: Path, output: Path) -> None:
    chrome = chrome_binary()
    if not chrome:
        fail("No se encontró Chrome/Chromium para generar resumen.pdf")
    with tempfile.TemporaryDirectory(prefix="aula-chrome-") as profile:
        command = [chrome, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--virtual-time-budget=5000", f"--user-data-dir={profile}", f"--print-to-pdf={output}", page.as_uri()]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        except subprocess.TimeoutExpired:
            if output.is_file() and output.stat().st_size >= 1000:
                return
            fail("Chrome agotó el tiempo antes de producir el PDF")
    if result.returncode or not output.is_file() or output.stat().st_size < 1000:
        fail(f"No se pudo generar el PDF: {(result.stderr or result.stdout).strip()}")


def catalog_entry(spec: dict, moments: list[dict]) -> dict:
    poster_index = min(max(int(spec.get("posterMomentIndex", 1)), 0), len(moments) - 1)
    frames = [f"clases/{spec['id']}/{moment['image']}" for moment in moments[:3]]
    return {
        "id": spec["id"],
        "slug": slug(spec["title"]),
        "title": spec["title"],
        "date": spec["date"],
        "dateLabel": spec["dateLabel"],
        "duration": spec["duration"],
        "durationSeconds": spec["durationSeconds"],
        "teacher": spec["teacher"],
        "summary": spec["summaryTeaser"],
        "thesis": spec["thesis"],
        "topics": spec.get("topics", []),
        "poster": f"clases/{spec['id']}/{moments[poster_index]['image']}",
        "frames": frames,
        "href": f"clases/{spec['id']}/",
        "pdf": f"clases/{spec['id']}/resumen.pdf",
        "status": "published",
    }


def update_catalog(project: Path, entry: dict) -> None:
    path = project / "data" / "classes.json"
    if not path.is_file():
        fail(f"No existe el catálogo: {path}")
    catalog = json.loads(path.read_text(encoding="utf-8"))
    if any(item.get("id") == entry["id"] for item in catalog):
        fail(f"La clase {entry['id']} ya existe en el catálogo")
    catalog.append(entry)
    catalog.sort(key=lambda item: (item.get("date", ""), item.get("id", "")), reverse=True)
    path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--skip-pdf", action="store_true", help="Solo para pruebas aisladas; una publicación final requiere PDF")
    args = parser.parse_args()
    spec_path = args.spec.expanduser().resolve()
    project = args.project.expanduser().resolve()
    if not spec_path.is_file() or not project.is_dir():
        fail("La especificación o el proyecto no existen")
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    validate(spec)
    validate_evidence(spec, spec_path.parent)
    target = project / "clases" / spec["id"]
    if target.exists():
        fail(f"Se niega a sobrescribir la clase existente: {target}")
    catalog_path = project / "data" / "classes.json"
    if not catalog_path.is_file():
        fail(f"No existe el catálogo: {catalog_path}")
    current_catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    if any(item.get("id") == spec["id"] for item in current_catalog):
        fail(f"La clase {spec['id']} ya existe en el catálogo")
    build = project / "clases" / f".build-{spec['id']}"
    if build.exists():
        shutil.rmtree(build)
    build.mkdir(parents=True)
    try:
        moments = extract_or_copy_frames(spec, spec_path.parent, build)
        active_index = min(1, len(moments) - 1)
        active = moments[active_index]
        nav, sections = render_sections(spec)
        summary_title = esc(spec["summaryTitle"])
        if spec.get("summaryAccent"):
            accent = esc(spec["summaryAccent"])
            summary_title = summary_title.replace(accent, f"<i>{accent}</i>", 1)
        suggestions = "".join(f"<button>{esc(item.get('question', item['terms'][0]))}</button>" for item in spec["knowledge"][:5])
        replacements = {
            "META_DESCRIPTION": esc(spec["summaryTeaser"]),
            "CLASS_ID": esc(spec["id"]),
            "DATE_LABEL": esc(spec["dateLabel"]),
            "DURATION": esc(spec["duration"]),
            "TITLE_HTML": title_html(spec["titleLines"], int(spec.get("accentLineIndex", len(spec["titleLines"]) - 1))),
            "THESIS": esc(spec["thesis"]),
            "TEACHER": esc(spec["teacher"]),
            "TEACHER_SHORT": esc(spec.get("teacherShort", spec["teacher"].split()[0])),
            "TIMELINE_MAX": str(len(moments) - 1),
            "ACTIVE_INDEX": str(active_index),
            "ACTIVE_TIME": esc(active["time"]),
            "ACTIVE_TEXT": esc(active["text"]),
            "ACTIVE_URL": esc(f"{spec['videoViewUrl']}?t={active['seconds']}s"),
            "VIDEO_ACCESS_NOTE": esc(spec.get("videoAccessNote", "La grabación conserva los permisos del archivo original.")),
            "READING_MINUTES": str(spec.get("readingMinutes", 12)),
            "SUMMARY_TEASER": esc(spec["summaryTeaser"]),
            "SUMMARY_NAV": nav,
            "SUMMARY_TITLE_HTML": summary_title,
            "STANDFIRST": esc(spec["standfirst"]),
            "SUMMARY_SECTIONS": sections,
            "COMMITMENTS": render_commitments(spec),
            "SUGGESTIONS": suggestions,
        }
        page = TEMPLATE.read_text(encoding="utf-8")
        for key, value in replacements.items():
            page = page.replace("{{" + key + "}}", value)
        leftovers = re.findall(r"{{[A-Z0-9_]+}}", page)
        if leftovers:
            fail(f"Marcadores sin resolver: {', '.join(leftovers)}")
        (build / "index.html").write_text(page, encoding="utf-8")
        class_data = {
            "classId": spec["id"],
            "fallbackTopics": spec.get("topics", []),
            "videoAccessNote": spec.get("videoAccessNote", "La grabación conserva los permisos del archivo original."),
            "videoEmbedUrl": spec["videoEmbedUrl"],
            "videoViewUrl": spec["videoViewUrl"],
            "moments": moments,
            "knowledge": spec["knowledge"],
        }
        (build / "content.js").write_text("window.CLASS_DATA = " + json.dumps(class_data, ensure_ascii=False, indent=2) + ";\n", encoding="utf-8")
        if not args.skip_pdf:
            make_pdf(build / "index.html", build / "resumen.pdf")
        build.rename(target)
        update_catalog(project, catalog_entry(spec, moments))
    except BaseException:
        if build.exists():
            shutil.rmtree(build)
        if target.exists():
            shutil.rmtree(target)
        raise
    print(json.dumps({"status": "created", "class": spec["id"], "page": str(target / "index.html"), "catalog": str(project / "data" / "classes.json"), "pdf": None if args.skip_pdf else str(target / "resumen.pdf")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
