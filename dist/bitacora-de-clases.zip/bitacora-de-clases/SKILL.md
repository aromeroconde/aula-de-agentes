---
name: bitacora-de-clases
description: Convierte grabaciones y transcripciones de capacitaciones en una bitácora sustanciosa, verificable y reutilizable con resumen profundo, momentos, conceptos, preguntas, compromisos y una base de conocimiento para chat. Úsala cuando el usuario pida resumir, documentar, publicar o volver consultable una clase, reunión educativa o taller.
---

# Bitácora de clases

Transforma una clase grabada en memoria útil. El resultado debe permitir comprender la sesión sin verla completa y regresar al minuto exacto cuando haga falta evidencia.

## Principios

- Escribe un resumen con argumento, contexto y conclusiones; nunca una ficha superficial.
- Usa únicamente hechos presentes en la transcripción, la grabación o archivos aportados.
- Separa `confirmado`, `propuesto` y `pendiente`. No inventes responsables, fechas ni compromisos.
- Conserva el lenguaje y los ejemplos distintivos del docente sin copiar largos pasajes verbatim.
- Cada afirmación importante debe poder rastrearse a un timestamp, una sección o un archivo.
- Distingue lo que explicó el docente, lo que preguntaron los participantes y lo que el agente infiere.

## Flujo obligatorio

### 1. Inventariar

Revisa la carpeta indicada de forma recursiva. Agrupa por clase:

- transcripción (`.docx`, `.txt`, `.vtt`, `.srt`, `.pdf`);
- grabación (`.mp4`, `.mov`, `.m4a`, `.mp3`, enlace remoto);
- material de apoyo (`.xlsx`, `.csv`, `.pdf`, imágenes, presentaciones);
- identidad visual (logo, fotografías, colores existentes).

Registra nombre, fecha, duración, tamaño y relación probable entre archivos. No copies videos pesados al entregable si pueden reproducirse desde su ubicación remota.

### 2. Reconstruir la sesión

Extrae, en este orden:

1. propósito real de la clase;
2. tesis o idea central;
3. recorrido del argumento;
4. demostraciones y ejemplos;
5. preguntas, objeciones y dudas de participantes;
6. errores, correcciones y aprendizajes surgidos en vivo;
7. reglas prácticas o procedimientos;
8. compromisos confirmados;
9. propuestas para continuar;
10. momentos clave con timestamps.

Cuando la transcripción no tenga timestamps confiables, decláralo. No fabriques minutos.

### 3. Redactar el resumen profundo

Usa el contrato de `references/output-contract.md`. El resumen debe tener suficiente carne para que alguien ausente entienda qué se discutió, por qué importa, cómo se demostró y qué criterio debería conservar. Evita una sucesión de bullets sin narrativa.

### 4. Preparar la base de conocimiento

Crea preguntas canónicas y respuestas breves apoyadas por evidencia. Incluye términos alternativos y errores de escritura previsibles. Para cada respuesta guarda:

- términos de activación;
- respuesta;
- evidencia temporal o documental;
- nivel de certeza.

Si no existe respaldo suficiente, la respuesta correcta es reconocer el límite y proponer preguntas que sí están cubiertas.

### 5. Producir los formatos solicitados

- Para lectura: HTML semántico o documento bien compuesto.
- Para descarga: PDF con título, fecha, índice, jerarquía y paginación legible.
- Para chat: JSON o JavaScript estructurado, separado de la interfaz.
- Para una biblioteca web: una entrada por clase, reproductor o enlace, resumen, momentos y chat con evidencia.

Si está disponible y el usuario pide alta calidad visual, aplica Impeccable al diseño público. La dirección visual debe surgir del contenido de la clase, no de un dashboard genérico.

### 6. Verificar antes de entregar

- Comprueba nombres, fecha y duración contra los archivos fuente.
- Contrasta al menos cinco afirmaciones importantes con la transcripción.
- Prueba todos los enlaces de reproducción y descarga.
- Comprueba que los timestamps seleccionados pertenecen al tema descrito.
- Revisa el PDF página por página y el HTML en escritorio y móvil.
- Prueba preguntas conocidas, ambiguas y fuera de alcance en el chat.
- Confirma que compromisos y responsables no fueron inferidos.

## Entrega

Informa qué clases fueron procesadas, qué fuentes se usaron, dónde quedaron los artefactos y qué limitaciones permanecen. Si la grabación requiere acceso a una cuenta, dilo de manera visible sin confundirlo con una falla del sitio.

