# Publicar una nueva clase en Aula de Agentes

Lee esta referencia cuando el usuario quiera incorporar una clase al proyecto `aula-de-agentes`.

## Entrada estructurada

Prepara un JSON conforme a `class-spec.schema.json`. Todos los textos deben provenir de la transcripción o de archivos confirmados. Registra como mínimo cinco afirmaciones en `evidenceChecks`; cada una debe incluir un fragmento literal breve que el generador pueda localizar en la transcripción. Las rutas de `sources` y `imageSource` pueden ser absolutas o relativas al archivo JSON.

El generador realiza mecánicamente lo siguiente:

- crea `clases/NNN/`;
- rechaza una especificación cuyos fragmentos de evidencia no estén en la transcripción;
- extrae un fotograma real en cada timestamp cuando no se suministra una imagen;
- escribe `content.js` para timeline y chat;
- compone la página con el sistema visual de Aula de Agentes;
- genera `resumen.pdf` con Chrome cuando está disponible;
- agrega o actualiza la entrada en `data/classes.json`;
- nunca copia la grabación pesada al repositorio.

## Ejecución

```bash
python3 ~/.codex/skills/bitacora-de-clases/scripts/create_class.py \
  /ruta/a/class-spec.json \
  /ruta/al/proyecto/aula-de-agentes
```

El identificador debe ser nuevo. El generador se niega a sobrescribir una clase existente.

## Verificación posterior

1. Servir el proyecto localmente.
2. Confirmar que la portada muestra la clase y enlaza a `/clases/NNN/`.
3. Recorrer todos los momentos y comprobar imagen, texto, timestamp y enlace.
4. Probar una pregunta canónica, una ambigua y una fuera de alcance.
5. Abrir `resumen.pdf` y revisar visualmente todas las páginas.
6. Revisar portada y detalle en escritorio y móvil.
7. Publicar solo después de que estas comprobaciones pasen.

## Límites

- El generador compone y publica contenido ya reconstruido; el agente sigue siendo responsable de leer las fuentes y producir el JSON verificado.
- Un enlace de Drive conserva los permisos del archivo original.
- Si Chrome o `ffmpeg` no están disponibles, el agente debe producir el PDF o los fotogramas con una herramienta equivalente antes de declarar la clase terminada.
