# Contrato de salida

## Resumen profundo

1. Título humano y específico.
2. Metadatos confirmados: fecha, duración, docente y fuentes.
3. Apertura narrativa: qué problema abrió la sesión y adónde llegó.
4. Idea central desarrollada en varios párrafos.
5. Casos o demostraciones, con datos y resultado.
6. Dudas y tensiones que cambiaron la conversación.
7. Aprendizajes y reglas operativas.
8. Criterio humano: qué puede delegarse y qué requiere aprobación.
9. Compromisos confirmados.
10. Propuestas para la siguiente clase, rotuladas como propuestas.
11. Cinco a diez momentos con timestamps.
12. Nota de fuentes y límites.

## Registro estructurado de una clase

```json
{
  "id": "clase-001",
  "title": "Título",
  "date": "YYYY-MM-DD",
  "duration_seconds": 0,
  "sources": [],
  "moments": [
    {
      "time": "00:00",
      "seconds": 0,
      "title": "Momento",
      "summary": "Descripción verificada"
    }
  ],
  "knowledge": [
    {
      "terms": [],
      "answer": "Respuesta respaldada",
      "evidence": "00:00",
      "certainty": "confirmed"
    }
  ],
  "commitments": [
    {
      "status": "confirmed|proposed|pending",
      "owner": null,
      "due_date": null,
      "text": "Compromiso o propuesta"
    }
  ],
  "limitations": []
}
```

## Umbral de calidad

El resumen no está listo si solo enumera temas. Debe explicar relaciones causales, decisiones, errores descubiertos, cambios de criterio y consecuencias prácticas. El lector debe poder contarle a otra persona qué pasó en la clase y por qué importa.

